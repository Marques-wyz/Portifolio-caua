package agenciaviagens;

public class PacoteViagem {
    private Transporte transporte;
    private Hospedagem hospedagem;
    private String destino;
    private int dias;
    private double margemLucro;
    private double taxasAdicionais;

    public PacoteViagem(Transporte transporte, Hospedagem hospedagem, String destino, int dias, double margemLucro, double taxasAdicionais) {
        this.transporte = transporte;
        this.hospedagem = hospedagem;
        this.destino = destino;
        this.dias = dias;
        this.margemLucro = margemLucro;
        this.taxasAdicionais = taxasAdicionais;
    }

    public double calcularValorFinal() {
        double custoHospedagem = hospedagem.calcularCustoTotal(dias);
        double valorBase = transporte.getValorDolar() + custoHospedagem;
        double lucro = valorBase * (margemLucro / 100.0);
        return valorBase + lucro + taxasAdicionais;
    }

    public String getDestino() {
        return destino;
    }

    public double getValorBase() {
        return transporte.getValorDolar() + hospedagem.calcularCustoTotal(dias);
    }
}