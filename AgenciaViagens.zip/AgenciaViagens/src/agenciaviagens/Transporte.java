package agenciaviagens;

public class Transporte {
    private String tipo;
    private double valorDolar;

    public Transporte(String tipo, double valorDolar) {
        this.tipo = tipo;
        this.valorDolar = valorDolar;
    }

    public String getTipo() {
        return tipo;
    }

    public double getValorDolar() {
        return valorDolar;
    }
}