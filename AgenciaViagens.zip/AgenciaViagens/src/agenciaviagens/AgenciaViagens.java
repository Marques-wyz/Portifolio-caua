package agenciaviagens;

import java.util.Scanner;

public class AgenciaViagens {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Cadastro de Transporte ===");
        System.out.print("Tipo (aéreo, rodoviário, etc.): ");
        String tipo = scanner.nextLine();
        System.out.print("Valor do transporte em dólar: ");
        double valorTransporte = scanner.nextDouble();
        scanner.nextLine();  // consumir quebra de linha

        Transporte transporte = new Transporte(tipo, valorTransporte);

        System.out.println("\n=== Cadastro de Hospedagem ===");
        System.out.print("Descrição da hospedagem: ");
        String descricao = scanner.nextLine();
        System.out.print("Valor da diária: ");
        double valorDiaria = scanner.nextDouble();

        Hospedagem hospedagem = new Hospedagem(descricao, valorDiaria);

        System.out.println("\n=== Criação do Pacote ===");
        scanner.nextLine(); // consumir quebra de linha
        System.out.print("Destino: ");
        String destino = scanner.nextLine();
        System.out.print("Quantidade de dias: ");
        int dias = scanner.nextInt();
        System.out.print("Margem de lucro (%): ");
        double margemLucro = scanner.nextDouble();
        System.out.print("Taxas adicionais: ");
        double taxas = scanner.nextDouble();

        PacoteViagem pacote = new PacoteViagem(transporte, hospedagem, destino, dias, margemLucro, taxas);

        System.out.println("\n=== Venda ===");
        scanner.nextLine(); // consumir quebra de linha
        System.out.print("Nome do cliente: ");
        String cliente = scanner.nextLine();
        System.out.print("Forma de pagamento: ");
        String pagamento = scanner.nextLine();
        System.out.print("Cotação do dólar: ");
        double cotacao = scanner.nextDouble();

        Venda venda = new Venda(cliente, pagamento, pacote, cotacao);

        System.out.println("\n=== Resumo da Venda ===");
        venda.exibirResumo();

        scanner.close();
    }
}