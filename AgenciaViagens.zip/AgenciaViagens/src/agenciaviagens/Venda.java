package agenciaviagens;

public class Venda {
    private String nomeCliente;
    private String formaPagamento;
    private PacoteViagem pacote;
    private double cotacaoDolar;

    public Venda(String nomeCliente, String formaPagamento, PacoteViagem pacote, double cotacaoDolar) {
        this.nomeCliente = nomeCliente;
        this.formaPagamento = formaPagamento;
        this.pacote = pacote;
        this.cotacaoDolar = cotacaoDolar;
    }

    public double calcularValorReais() {
        return pacote.calcularValorFinal() * cotacaoDolar;
    }

    public void exibirResumo() {
        System.out.println("Cliente: " + nomeCliente);
        System.out.println("Destino: " + pacote.getDestino());
        System.out.println("Forma de pagamento: " + formaPagamento);
        System.out.printf("Total em dólar: U$ %.2f\n", pacote.calcularValorFinal());
        System.out.printf("Cotação: R$ %.2f\n", cotacaoDolar);
        System.out.printf("Total em reais: R$ %.2f\n", calcularValorReais());
    }
}