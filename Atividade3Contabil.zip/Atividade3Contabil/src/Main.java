import java.util.Scanner;
import br.com.atividade3.model.*;

public class Main {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Digite o nome da empresa: ");
            String nomeEmpresa = sc.nextLine();
            
            Pagamentos pagamentos = new Pagamentos(nomeEmpresa);
            
            while (true) {
                System.out.print("Digite o tipo de imposto (PIS/IPI) ou 'pare' para encerrar: ");
                String tipo = sc.nextLine().trim().toLowerCase();
                
                if (tipo.equals("pare")) {
                    break;
                }
                
                switch (tipo) {
                    case "pis":
                        System.out.print("Digite o valor do débito: ");
                        double debito = sc.nextDouble();
                        System.out.print("Digite o valor do crédito: ");
                        double credito = sc.nextDouble();
                        sc.nextLine(); // limpar buffer
                        Imposto pis = new Pis(debito, credito);
                        pagamentos.adicionarImposto(pis);
                        break;
                    case "ipi":
                        System.out.print("Digite o valor do produto: ");
                        double produto = sc.nextDouble();
                        System.out.print("Digite o valor do frete: ");
                        double frete = sc.nextDouble();
                        System.out.print("Digite o valor do seguro: ");
                        double seguro = sc.nextDouble();
                        System.out.print("Digite outras despesas: ");
                        double outras = sc.nextDouble();
                        System.out.print("Digite a alíquota (%): ");
                        double aliquota = sc.nextDouble();
                        sc.nextLine(); // limpar buffer
                        Imposto ipi = new Ipi(produto, frete, seguro, outras, aliquota);
                        pagamentos.adicionarImposto(ipi);
                        break;
                    default:
                        System.out.println("Tipo inválido. Tente novamente.");
                        break;
                }
            }
            
            System.out.println("\n--- IMPOSTOS CADASTRADOS ---");
            pagamentos.mostrarImpostos();
        }
    }
}
