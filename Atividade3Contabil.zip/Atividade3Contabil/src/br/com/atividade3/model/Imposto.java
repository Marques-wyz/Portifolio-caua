package br.com.atividade3.model;
public interface Imposto{
    double calcularImposto();
    String getDescricao();
}