package app;

import model.Funcionario;
import model.FuncionarioAssalariado;
import model.FuncionarioHorista;
import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Funcionario> funcionarios = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            System.out.print("Digite o tipo de funcionário (1 - Assalariado, 2 - Horista, 0 - Sair): ");
            int tipo = sc.nextInt();
            sc.nextLine(); // Limpar o buffer

            if (tipo == 0) break;

            System.out.print("Nome: ");
            String nome = sc.nextLine();
            System.out.print("CPF: ");
            String cpf = sc.nextLine();
            System.out.print("Endereço: ");
            String endereco = sc.nextLine();
            System.out.print("Telefone: ");
            String telefone = sc.nextLine();
            System.out.print("Setor: ");
            String setor = sc.nextLine();

            if (tipo == 1) {
                System.out.print("Salário mensal: ");
                double salario = sc.nextDouble();
                sc.nextLine();
                funcionarios.add(new FuncionarioAssalariado(nome, cpf, endereco, telefone, setor, salario));
            } else if (tipo == 2) {
                System.out.print("Horas trabalhadas: ");
                double horas = sc.nextDouble();
                System.out.print("Valor por hora: ");
                double valorHora = sc.nextDouble();
                sc.nextLine();
                funcionarios.add(new FuncionarioHorista(nome, cpf, endereco, telefone, setor, horas, valorHora));
            } else {
                System.out.println("Tipo inválido!");
                i--; // repetir a iteração
            }
        }

        System.out.println("\n=== Funcionários cadastrados ===");
        for (Funcionario f : funcionarios) {
            f.mostrarDados();
            System.out.println("Salário: R$ " + f.calcularSalario());
            System.out.println();
        }

        System.out.print("Digite o percentual de aumento (%): ");
        double aumento = sc.nextDouble();

        System.out.println("\n=== Após aumento ===");
        for (Funcionario f : funcionarios) {
            f.aplicarAumento(aumento);
            f.mostrarDados();
            System.out.println("Novo salário: R$ " + f.calcularSalario());
            System.out.println();
        }

        sc.close();
    }
}
